from tkinter import *
import time
from tkinter import ttk, messagebox, filedialog
import pandas
import mysql.connector
from tkinter.ttk import *
import ttkthemes
import tkinter as tk

# Connect to MySQL database
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="student_attendance"
)

# Create a cursor object
cursor = db.cursor()

# Declare global variables
checkbox_vars = []
checkboxes = []
students = []


# Define function to display students
def display_students():
    # Destroy previous labels and checkboxes
    for label in loginFrame.grid_slaves(column=0):
        if int(label.grid_info()["row"]) >= 4:
            label.destroy()
    for checkbox in loginFrame.grid_slaves(column=1):
        if int(checkbox.grid_info()["row"]) >= 4:
            checkbox.destroy()

    # Retrieve student names from database for the selected division
    cursor.execute("SELECT name FROM student WHERE division = %s", (selected_division.get(),))
    students = cursor.fetchall()

    global checkbox_vars
    global checkboxes

    checkbox_vars = []
    checkboxes = []

    def on_checkbox_clicked(index):
        print(f"Checkbox {index} clicked")

    for i, student in enumerate(students):
        tk.Label(loginFrame, text=student[0]).grid(row=i + 4, column=0)
        checkbox_var = tk.BooleanVar()
        checkbox_vars.append(checkbox_var)
        checkbox = tk.Checkbutton(loginFrame, variable=checkbox_var, command=lambda index=i: on_checkbox_clicked(index))
        checkbox.grid(row=i + 4, column=1)
        checkboxes.append(checkbox)
    # Set the global variables for checkbox variables and checkboxes
    checkbox_vars = checkbox_vars
    checkboxes = checkboxes


count = 0
text = ''


def slider():
    global text, count

    if count == len(s):
        # hold the last slide instead of a blank space
        text = s
    else:
        text = text + s[count]

    sliderLabel.config(text=text)
    count += 1

    if count > len(s):
        # wait for some time and then start over
        count = 0
        text = ''
        root.after(2000, slider)
    else:
        # continue sliding
        sliderLabel.after(100, slider)


def clock():
    global date, currenttime
    date = time.strftime('%d/%m/%Y')
    currenttime = time.strftime('%H:%M:%S')
    datetimeLabel.config(text=f'Date: {date}\nTime: {currenttime}')
    datetimeLabel.after(1000, clock)


def go_back():
    root.destroy()
    import admin


def page_exit():
    result = messagebox.askyesno('Confirm', 'Do you want to exit?')
    if result:
        root.destroy()
    else:
        pass


# GUI


root = ttkthemes.ThemedTk()

root.get_themes()

root.set_theme('radiance')

root.geometry('1174x680+0+0')
root.resizable(0, 0)
root.title('Student Attendance System')

datetimeLabel = Label(root, font=('times new roman', 18, 'bold'))
datetimeLabel.place(x=5, y=5)
clock()
s = 'Student Attendance System'  # s[count]=t when count is 1
sliderLabel = Label(root, font=('arial', 28, 'italic bold'), width=30)
sliderLabel.place(x=200, y=0)
slider()





# connectButton = ttk.Button(root, text='Connect database')
# connectButton.place(x=980, y=0)

BackButton = ttk.Button(root, text='Go Back', command=go_back)
BackButton.place(x=980, y=40)

leftFrame = Frame(root)
leftFrame.place(x=50, y=80, width=300, height=600)

loginFrame = Frame(root)
loginFrame.place(x=500, y=80 ,width=600, height=600)
# logo_image = PhotoImage(file='C:/Users/mparg/Downloads/AttendanceSystem/Student Management System/Student Management System/student.png')
# logo_Label = Label(leftFrame)
# logo_Label.grid(row=0, column=0)
tk.Label(loginFrame, text="Select Division").grid(row=1, column=0)

# Create a variable to store the selected division
selected_division = tk.StringVar(value="A")

# Define a function to be called when a division is selected
def on_division_selected():
    display_students()
# Add a checkbox for each division
divisions = ["A", "B", "C"]
checkboxes = []
for i, division in enumerate(divisions):
    checkbox = tk.Radiobutton(loginFrame, text=division, variable=selected_division, value=division,command=on_division_selected)
    checkbox.grid(row=2, column= i + 0)
    checkboxes.append(checkbox)


# Display students for the initial selected division
display_students()
submit_btn = ttk.Button(leftFrame, text='Mark Attendance', width=25,
                        command=lambda: mark_attendance())
submit_btn.grid(row=9, column=0, pady=20)

showstudentButton = ttk.Button(leftFrame, text='Show Attendance', width=25,
                               command=lambda: show_attendance())
showstudentButton.grid(row=10, column=0, pady=20)

exitButton = ttk.Button(leftFrame, text='Exit', width=25, command=page_exit)
exitButton.grid(row=11, column=0, pady=20)

# attendance_list = tk.Listbox(loginFrame,width=100)
# attendance_list.grid(row=1, column=4)
#

# Define function to insert attendance data
def mark_attendance():
    # Get the selected division
    division = selected_division.get()

    # Retrieve students from database for the selected division
    cursor.execute("SELECT name FROM student WHERE division = %s", (division,))
    students = cursor.fetchall()

    # Insert attendance data into database for each student in the selected division
    for i, student in enumerate(students):
        student_name = student[0]
        checkbox_value = checkbox_vars[i].get()
        if checkbox_value:
            status = "Present"
        else:
            status = "Absent"
        sql = "INSERT INTO attendance (student_name, date, status) VALUES (%s, %s, %s)"
        val = (student_name, date, status)
        cursor.execute(sql, val)
        db.commit()

    # Display attendance data
    # show_attendance()


# Define function to display attendance data
def show_attendance():
    # Clear the listbox first
    # attendance_list.delete(0, tk.END)
    division = selected_division.get()

    # Retrieve attendance data from database
    cursor.execute("SELECT student_name,status FROM attendance WHERE status = 'Present'")
    data = cursor.fetchall()

    # Display attendance data on GUI
    for row in data:
        for i in range(1):
            student_name = row[0]
            status = row[1]
            Label(loginFrame,text=student_name).grid(row=10,column=2)
            Label(loginFrame,text=status).grid(row=10,column=3)


#     # Calculate and display total present and absent numbers
#     present_count = len([row for row in data if row[3] == "Present"])
#     absent_count = len([row for row in data if row[6] == "Absent"])
#     present_label.config(text=f"Present: {present_count}")
#     present_label.grid(row=len(students) + 12, column=5)
#     absent_label.config(text=f"Absent: {absent_count}")
#     absent_label.grid(row=len(students) + 13, column=6)
#
#
# # Add labels for present and absent counts
# present_label = tk.Label(leftFrame, text="Present: 0")
# present_label.grid(row=len(students) + 12, column=0)
#
# absent_label = tk.Label(leftFrame, text="Absent: 0")
# absent_label.grid(row=len(students) + 13, column=0)

root.mainloop()
db.close()