from tkinter import *
from tkinter import messagebox

def manage():
    window.destroy()
    import sms

def take():
    window.destroy()
    import attendance

window = Tk()

window.geometry('950x380')

window.resizable(False, False)

AdminFrame = Frame(window, bg='white')
AdminFrame.place(x=200, y=50)

TakeAttandanceImage = PhotoImage(file='attendance.png')
TakeAttandanceLabel = Label(AdminFrame, image=TakeAttandanceImage, compound=RIGHT
                      , font=('times new roman', 20, 'bold'), bg='white')
TakeAttandanceLabel.grid(row=1, column=0,padx=10,pady=20)


TakeAttandanceButton = Button(AdminFrame, text='Take Attendance', font=('times new roman', 20, 'bold'), width=15
                     , fg='white', bg='cornflowerblue', activebackground='cornflowerblue',
                     activeforeground='white', cursor='plus',command=take)
TakeAttandanceButton.grid(row=1, column=1,padx=10,pady=20)


ManageAttandanceImage = PhotoImage(file='process.png')
ManageAttandanceLabel = Label(AdminFrame, image=ManageAttandanceImage, compound=LEFT
                      , font=('times new roman', 20, 'bold'), bg='white')
ManageAttandanceLabel.grid(row=3, column=0,padx=10,pady=20)

ManageAttandanceButton = Button(AdminFrame, text='Manage Attendance', font=('times new roman', 20, 'bold'), width=15
                     , fg='white', bg='cornflowerblue', activebackground='cornflowerblue',
                     activeforeground='white', cursor='circle',command=manage)
ManageAttandanceButton.grid(row=3, column=1,padx=10,pady=20)

window.mainloop()
